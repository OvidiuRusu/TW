DROP TABLE EMP_MANAGER;
DROP TABLE EMP_CLERK;
DROP TABLE EMP_SALESMAN;
DROP TABLE EMP_ANALYST;
DROP TABLE EMP_PRESIDENT;

DECLARE
    CURSOR emp_cursor IS 
      SELECT empno from emp order by sal desc;
    v_CursorID NUMBER;
    v_CreateTableString VARCHAR2(500);
    v_NUMRows INTEGER;
    best_emp emp.ename%TYPE;
    tname VARCHAR2(30);
    v_InsertRecords  VARCHAR2(500);
    v_DropTable VARCHAR2(500);
    i INTEGER;

BEGIN
    v_CursorID := DBMS_SQL.OPEN_CURSOR;
    select ename INTO best_emp from emp
    where comm = (select max(comm) from emp);
    v_CreateTableString := 'CREATE TABLE CONTRACT_ORANGE_' || best_emp || '(
      	empno INTEGER,
        telefon VARCHAR2(50))';

    DBMS_SQL.PARSE(v_CursorID,v_CreateTableString,DBMS_SQL.V7);
    v_NumRows := DBMS_SQL.EXECUTE(v_CursorID);
    
    v_InsertRecords := 'INSERT INTO CONTRACT_ORANGE_MARTIN(empno, telefon) VALUES (:empnr,:tel)';
  
    DBMS_SQL.PARSE(v_CursorID,v_InsertRecords,DBMS_SQL.V7);
    i:=1;
    FOR v_emp_record IN emp_cursor LOOP
      DBMS_SQL.BIND_VARIABLE(v_CursorID, ':empnr', v_emp_record.empno);
      IF i<10 THEN  
        DBMS_SQL.BIND_VARIABLE(v_CursorID, ':tel','074100000' || i);
      ELSE
        DBMS_SQL.BIND_VARIABLE(v_CursorID, ':tel','07410000' || i);
      END IF;  
      v_NumRows := DBMS_SQL.EXECUTE(v_CursorID);
      i:= i + 1;
    END LOOP;  

 	EXCEPTION
      	WHEN OTHERS THEN
           	IF SQLCODE != -955 THEN
                RAISE;
           	ELSE
                DBMS_OUTPUT.PUT_LINE('Table Already Exists!');
           	END IF;
    DBMS_SQL.CLOSE_CURSOR(v_CursorID);
 END;
 
DROP TABLE CONTRACT_ORANGE_MARTIN;
SELECT * FROM CONTRACT_ORANGE_MARTIN;

DECLARE
    CURSOR job_cursor IS 
      SELECT DISTINCT job from emp;
    v_CursorID NUMBER;
    v_CreateTableString VARCHAR2(500);
    v_NUMRows INTEGER;
    v_InsertRecords  VARCHAR2(500);
    v_DropTable VARCHAR2(500);

BEGIN
    v_CursorID := DBMS_SQL.OPEN_CURSOR;
    FOR job_record IN job_cursor LOOP 
      v_CreateTableString := 'CREATE TABLE EMP_' || job_record.job || '(
        EMPNO NUMBER(4), 
        ENAME CHAR(10), 
        MGR NUMBER(4), 
        HIREDATE DATE, 
        SAL NUMBER(7,2), 
        COMM NUMBER(7,2), 
        DEPTNO NUMBER(2))';

      DBMS_SQL.PARSE(v_CursorID,v_CreateTableString,DBMS_SQL.V7);
      v_NumRows := DBMS_SQL.EXECUTE(v_CursorID);
    
      v_InsertRecords := 'INSERT INTO EMP_' || job_record.job || '(empno, ename, mgr, hiredate, sal, comm, deptno) VALUES (:empno,:ename,:mgr,:hiredate,:sal,:comm,:deptno)';
      DBMS_SQL.PARSE(v_CursorID,v_InsertRecords,DBMS_SQL.V7);

      FOR v_emp_record IN (select * from emp where job = job_record.job) LOOP
        DBMS_SQL.BIND_VARIABLE(v_CursorID, ':empno', v_emp_record.empno);
        DBMS_SQL.BIND_VARIABLE(v_CursorID, ':ename', v_emp_record.ename);
        DBMS_SQL.BIND_VARIABLE(v_CursorID, ':mgr', v_emp_record.mgr);
        DBMS_SQL.BIND_VARIABLE(v_CursorID, ':hiredate', v_emp_record.hiredate);
        DBMS_SQL.BIND_VARIABLE(v_CursorID, ':sal', v_emp_record.sal);
        DBMS_SQL.BIND_VARIABLE(v_CursorID, ':comm', v_emp_record.comm);
        DBMS_SQL.BIND_VARIABLE(v_CursorID, ':deptno', v_emp_record.deptno);
        v_NumRows := DBMS_SQL.EXECUTE(v_CursorID);
      END LOOP;  
    END LOOP; 
    v_DropTable := 'DROP TABLE EMP_SALESMAN';
    DBMS_SQL.PARSE(v_CursorID, v_DropTable, DBMS_SQL.V7);
    v_NumRows := DBMS_SQL.EXECUTE(v_CursorID); 

 	EXCEPTION
      	WHEN OTHERS THEN
           	IF SQLCODE != -955 THEN
                RAISE;
           	ELSE
                DBMS_OUTPUT.PUT_LINE('Table Already Exists!');
           	END IF;
  DBMS_SQL.CLOSE_CURSOR(v_CursorID);
 END;
 
 select * from EMP_MANAGER;
 select * from EMP_CLERK;
 select * from EMP_SALESMAN;
 select * from EMP_ANALYST;
 select * from EMP_PRESIDENT;
 
 